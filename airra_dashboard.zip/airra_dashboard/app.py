from __future__ import annotations

import hashlib
from datetime import datetime
from pathlib import Path

import pandas as pd
import plotly.express as px
import streamlit as st

from services import classify_document, extract_text, load_demo_data, ollama_answer, search_records

st.set_page_config(page_title="AIRRA | AI Records & Registry Assistant", page_icon="A", layout="wide", initial_sidebar_state="expanded")

st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Space+Grotesk:wght@500;600;700&display=swap');
:root { --ink:#10243e; --muted:#64748b; --line:rgba(148,163,184,.22); --blue:#2368f2; --cyan:#00b8d9; --violet:#7357ff; }
html, body, [class*="css"] { font-family:'DM Sans', sans-serif; }
.stApp { background: radial-gradient(circle at 4% 2%, rgba(67,145,255,.16), transparent 28%), radial-gradient(circle at 92% 8%, rgba(116,86,255,.14), transparent 25%), linear-gradient(135deg,#eff7ff 0%,#f7fbff 48%,#f5f2ff 100%); color:var(--ink); }
[data-testid="stSidebar"] { background:linear-gradient(180deg,rgba(255,255,255,.74),rgba(237,246,255,.70)); border-right:1px solid rgba(255,255,255,.92); }
[data-testid="stSidebar"] > div:first-child { padding-top:1.6rem; }
.block-container { padding:2.2rem 3rem 3rem; max-width:1500px; }
.glass { background:rgba(255,255,255,.66); border:1px solid rgba(255,255,255,.96); box-shadow:0 16px 46px rgba(35,76,129,.10), inset 0 1px 0 rgba(255,255,255,.78); backdrop-filter:blur(18px); -webkit-backdrop-filter:blur(18px); border-radius:24px; padding:1.35rem 1.5rem; }
.brand { font-family:'Space Grotesk',sans-serif; letter-spacing:-.04em; font-size:1.45rem; font-weight:700; color:#17345b; }
.brand-mark { display:inline-flex; align-items:center; justify-content:center; width:36px; height:36px; margin-right:10px; border-radius:12px; color:white; background:linear-gradient(135deg,var(--blue),var(--violet)); box-shadow:0 8px 22px rgba(35,104,242,.32); }
.eyebrow { color:var(--blue); font-size:.73rem; font-weight:700; letter-spacing:.14em; text-transform:uppercase; }
.hero-title { font-family:'Space Grotesk',sans-serif; font-size:clamp(2rem,3.5vw,3.65rem); line-height:1.02; letter-spacing:-.065em; color:#112f54; margin:.3rem 0 .75rem; }
.hero-copy { color:#58708e; font-size:1rem; max-width:720px; line-height:1.65; }
.kpi { position:relative; overflow:hidden; min-height:128px; }
.kpi:after { content:''; position:absolute; width:120px; height:120px; right:-50px; top:-50px; border-radius:50%; background:rgba(35,104,242,.10); }
.kpi-label { color:#64748b; font-size:.78rem; font-weight:600; text-transform:uppercase; letter-spacing:.08em; }
.kpi-value { font-family:'Space Grotesk',sans-serif; color:#17345b; font-size:2.25rem; font-weight:700; letter-spacing:-.06em; margin:.35rem 0 .1rem; }
.kpi-note { color:#2368f2; font-size:.79rem; font-weight:600; }
.section-title { font-family:'Space Grotesk',sans-serif; font-size:1.22rem; font-weight:700; letter-spacing:-.03em; color:#17345b; }
.mini { color:#71849c; font-size:.82rem; }
.pill { display:inline-flex; align-items:center; border-radius:999px; padding:.25rem .62rem; font-size:.72rem; font-weight:700; background:rgba(35,104,242,.10); color:#2368f2; }
.pill-success { background:rgba(16,185,129,.12); color:#047857; }
.pill-warn { background:rgba(245,158,11,.15); color:#a16207; }
.pill-neutral { background:rgba(100,116,139,.12); color:#475569; }
.doc-row { padding:.82rem 0; border-bottom:1px solid var(--line); }
.doc-row:last-child { border-bottom:0; }
.doc-title { color:#19375f; font-weight:700; font-size:.93rem; }
.doc-meta { color:#6b7f97; font-size:.78rem; line-height:1.5; }
.audit-dot { display:inline-block; width:9px; height:9px; border-radius:50%; background:var(--blue); box-shadow:0 0 0 5px rgba(35,104,242,.10); margin:0 .6rem .05rem .1rem; }
div[data-testid="stMetric"] { background:rgba(255,255,255,.42); border:1px solid rgba(255,255,255,.74); border-radius:16px; padding:.8rem; }
.stButton > button { border-radius:12px; border:1px solid rgba(35,104,242,.2); font-weight:700; color:#2254ba; background:rgba(255,255,255,.63); }
.stButton > button:hover { color:white; background:linear-gradient(135deg,var(--blue),var(--violet)); border-color:transparent; }
.stDownloadButton > button { border-radius:12px; font-weight:700; }
[data-testid="stDataFrame"] { border-radius:18px; overflow:hidden; }
hr { border-color:rgba(148,163,184,.18); }
</style>
""", unsafe_allow_html=True)


def init_state() -> None:
    if "data" not in st.session_state:
        st.session_state.data = load_demo_data()
    if "documents" not in st.session_state:
        st.session_state.documents = st.session_state.data["documents"][:]
    if "file_index" not in st.session_state:
        st.session_state.file_index = st.session_state.data["file_index"][:]
    if "audit_trail" not in st.session_state:
        st.session_state.audit_trail = st.session_state.data["audit_trail"][:]
    if "processed_uploads" not in st.session_state:
        st.session_state.processed_uploads = set()


def add_audit(event: str, subject: str, actor: str = "Current officer", tone: str = "info") -> None:
    st.session_state.audit_trail.insert(0, {"time": datetime.now().strftime("%H:%M"), "event": event, "subject": subject, "actor": actor, "tone": tone})


def status_pill(status: str) -> str:
    css = "pill-success" if status == "Filed" else "pill-warn" if "Awaiting" in status else "pill-neutral"
    return f'<span class="pill {css}">{status}</span>'


init_state()
documents = st.session_state.documents
file_index = st.session_state.file_index

with st.sidebar:
    st.markdown('<div class="brand"><span class="brand-mark">A</span>AIRRA</div>', unsafe_allow_html=True)
    st.caption("AI Records & Registry Assistant")
    st.markdown("---")
    page = st.radio("Workspace", ["Overview", "Review queue", "Documents", "File index", "AI assistant", "Audit trail"], label_visibility="collapsed")
    st.markdown("---")
    st.markdown('<div class="mini"><strong>Workspace status</strong><br>Offline-first demo mode<br><span style="color:#047857">● Secure local processing</span></div>', unsafe_allow_html=True)
    st.markdown("<br>", unsafe_allow_html=True)
    with st.expander("Upload document", expanded=page in ["Overview", "Review queue"]):
        upload = st.file_uploader("PDF, Word, image, or text", type=["pdf", "docx", "png", "jpg", "jpeg", "txt", "md"], label_visibility="collapsed")
        if upload is not None:
            fingerprint = hashlib.sha256(upload.getvalue()).hexdigest()
            if fingerprint not in st.session_state.processed_uploads:
                raw_text = extract_text(upload.name, upload.getvalue())
                recommendation = classify_document(raw_text, upload.name, file_index)
                new_id = f"DOC-{datetime.now().strftime('%Y%m%d%H%M%S')}"
                record = {"id": new_id, "title": recommendation["subject"], "type": recommendation["document_type"], "department": recommendation["department"], "classification": recommendation["classification"], "file_number": recommendation["file_number"], "date_received": datetime.now().strftime("%Y-%m-%d"), "sender": "Uploaded by current officer", "status": recommendation["status"], "confidence": recommendation["confidence"], "related_documents": recommendation["related_documents"], "keywords": recommendation["keywords"], "action": "Review", "source_file": upload.name, "extracted_text": raw_text[:3000]}
                documents.insert(0, record)
                st.session_state.processed_uploads.add(fingerprint)
                add_audit("Document uploaded and classified", upload.name, tone="info")
                st.success(f"Added to review queue at {recommendation['confidence']}% confidence.")
            else:
                st.info("This upload is already in the current session.")
    st.caption("Version 1.0 · Synthetic demo data")

# Header
left, right = st.columns([4.5, 1.4])
with left:
    st.markdown('<div class="eyebrow">Records operations workspace</div>', unsafe_allow_html=True)
    st.markdown('<div class="hero-title">A calmer way to receive,<br>understand, and file records.</div>', unsafe_allow_html=True)
    st.markdown('<div class="hero-copy">AIRRA turns incoming correspondence into clear, reviewable recommendations. It helps registry teams find the right file while keeping the officer in control.</div>', unsafe_allow_html=True)
with right:
    st.markdown('<div class="glass" style="text-align:center; padding:1rem; margin-top:.6rem;"><div style="font-size:2rem; color:#2368f2;">●</div><strong style="color:#17345b;">Local mode active</strong><div class="mini">No document leaves this workspace</div></div>', unsafe_allow_html=True)

st.markdown("<br>", unsafe_allow_html=True)

if page == "Overview":
    awaiting = sum(1 for d in documents if d.get("status") == "Awaiting approval")
    filed = sum(1 for d in documents if d.get("status") == "Filed")
    high_conf = sum(1 for d in documents if d.get("confidence", 0) >= 90)
    kpis = [("Documents today", len(documents) + 41, "+12% from yesterday"), ("Files processed", filed + 28, "Across 6 departments"), ("AI classifications", high_conf + 34, "90%+ confidence"), ("Awaiting approval", awaiting, "Needs officer review")]
    cols = st.columns(4)
    for col, (label, value, note) in zip(cols, kpis):
        with col:
            st.markdown(f'<div class="glass kpi"><div class="kpi-label">{label}</div><div class="kpi-value">{value}</div><div class="kpi-note">{note}</div></div>', unsafe_allow_html=True)
    st.markdown("<br>", unsafe_allow_html=True)
    a, b = st.columns([1.35, .9])
    with a:
        st.markdown('<div class="glass"><div class="section-title">Today at a glance</div><div class="mini">A lightweight view of the current filing workload.</div>', unsafe_allow_html=True)
        chart_df = pd.DataFrame({"Department": ["ICT", "Administration", "Facilities", "Human Resource", "Finance"], "Received": [12, 9, 6, 8, 7], "Filed": [9, 7, 6, 5, 7]})
        chart_long = chart_df.melt(id_vars="Department", var_name="Stage", value_name="Records")
        fig = px.bar(chart_long, x="Department", y="Records", color="Stage", barmode="group", color_discrete_map={"Received":"#85b7ff", "Filed":"#7357ff"}, height=265)
        fig.update_layout(margin=dict(l=0,r=0,t=18,b=0), paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)", font_color="#71849c", legend=dict(orientation="h", y=1.12, x=0), xaxis_title=None, yaxis_title=None)
        fig.update_xaxes(showgrid=False); fig.update_yaxes(showgrid=True, gridcolor="rgba(148,163,184,.16)")
        st.plotly_chart(fig, use_container_width=True, config={"displayModeBar": False})
        st.markdown('</div>', unsafe_allow_html=True)
    with b:
        st.markdown('<div class="glass"><div class="section-title">Priority review</div><div class="mini">The next three items that need a human decision.</div>', unsafe_allow_html=True)
        queue = [d for d in documents if d.get("status") == "Awaiting approval"][:3]
        if not queue: st.success("Review queue is clear.")
        for item in queue:
            st.markdown(f'<div class="doc-row"><div class="doc-title">{item["title"]}</div><div class="doc-meta">{item["file_number"]} · {item["confidence"]}% confidence</div></div>', unsafe_allow_html=True)
        st.markdown('</div>', unsafe_allow_html=True)
    st.markdown("<br>", unsafe_allow_html=True)
    c, d = st.columns([1.15, .85])
    with c:
        st.markdown('<div class="glass"><div class="section-title">Recent documents</div><div class="mini">Latest items entering the registry workflow.</div>', unsafe_allow_html=True)
        for item in documents[:5]:
            st.markdown(f'<div class="doc-row"><div class="doc-title">{item["title"]}</div><div class="doc-meta">{item["department"]} · {item["file_number"]} · <strong>{item["confidence"]}%</strong> match</div></div>', unsafe_allow_html=True)
        st.markdown('</div>', unsafe_allow_html=True)
    with d:
        st.markdown('<div class="glass"><div class="section-title">Live audit trail</div><div class="mini">Every recommendation remains reviewable.</div>', unsafe_allow_html=True)
        for event in st.session_state.audit_trail[:5]:
            st.markdown(f'<div class="doc-row"><div class="doc-meta"><span class="audit-dot"></span>{event["time"]} · {event["event"]}</div><div class="doc-title" style="font-size:.85rem; margin-left:1.1rem;">{event["subject"]}</div></div>', unsafe_allow_html=True)
        st.markdown('</div>', unsafe_allow_html=True)

elif page == "Review queue":
    st.markdown('<div class="eyebrow">Human approval checkpoint</div><div class="section-title" style="font-size:2rem; margin:.25rem 0 .4rem;">Review queue</div><div class="mini">AI recommends. The records officer decides what becomes official.</div>', unsafe_allow_html=True)
    queue = [d for d in documents if d.get("status") == "Awaiting approval"]
    if not queue:
        st.success("No records are waiting for approval.")
    for item in queue:
        with st.container(border=True):
            top, score = st.columns([4, 1])
            with top:
                st.markdown(f"#### {item['title']}")
                st.caption(f"{item['id']} · {item.get('source_file', 'Office correspondence')} · received {item['date_received']}")
            with score:
                st.metric("Match", f"{item['confidence']}%")
            l, r = st.columns([1.3, .8])
            with l:
                st.markdown(f"**Suggested file**  \n`{item['file_number']}`  \n{item['classification']}  \n**Related records:** {item.get('related_documents', 0)}")
                st.markdown(" ".join(f"`{word}`" for word in item.get("keywords", [])))
            with r:
                st.markdown(status_pill(item["status"]), unsafe_allow_html=True)
                if st.button("Approve filing", key=f"approve_{item['id']}", use_container_width=True):
                    item["status"] = "Filed"; item["action"] = "Filed"; add_audit("Officer approved filing", item["title"], tone="success"); st.rerun()
                if st.button("Change file", key=f"change_{item['id']}", use_container_width=True):
                    st.session_state[f"edit_{item['id']}"] = True
                if st.session_state.get(f"edit_{item['id']}"):
                    options = [entry["file_number"] for entry in file_index]
                    selected = st.selectbox("Choose file", options, key=f"select_{item['id']}")
                    if st.button("Save recommendation", key=f"save_{item['id']}"):
                        match = next(entry for entry in file_index if entry["file_number"] == selected); item["file_number"] = selected; item["classification"] = match["classification"]; item["department"] = match["department"]; item["confidence"] = max(70, item["confidence"] - 4); add_audit("Officer changed recommended file", item["title"]); st.rerun()

elif page == "Documents":
    st.markdown('<div class="eyebrow">Searchable records workspace</div><div class="section-title" style="font-size:2rem; margin:.25rem 0 .4rem;">Documents</div>', unsafe_allow_html=True)
    q = st.text_input("Search documents", placeholder="Search title, department, file number, sender, or keyword")
    departments = ["All departments"] + sorted({d.get("department", "") for d in documents})
    department = st.selectbox("Department", departments, label_visibility="collapsed")
    visible = documents[:]
    if q:
        needle = q.lower(); visible = [d for d in visible if needle in str(d).lower()]
    if department != "All departments": visible = [d for d in visible if d.get("department") == department]
    st.caption(f"Showing {len(visible)} of {len(documents)} documents")
    if visible:
        df = pd.DataFrame([{"Title": d["title"], "Department": d["department"], "File number": d["file_number"], "Received": d["date_received"], "Status": d["status"], "Confidence": f"{d['confidence']}%"} for d in visible])
        st.dataframe(df, use_container_width=True, hide_index=True, height=330)
        st.markdown("### Record detail")
        chosen = st.selectbox("Choose a record", [d["title"] for d in visible], label_visibility="collapsed")
        item = next(d for d in visible if d["title"] == chosen)
        x, y = st.columns([1.1, .9])
        with x:
            st.markdown(f'<div class="glass"><div class="eyebrow">{item["id"]}</div><div class="section-title">{item["title"]}</div><p class="mini">{item.get("type", "Office document")} · {item.get("sender", "Unknown sender")}</p><hr><strong>Classification</strong><br>{item["classification"]}<br><br><strong>Suggested file</strong><br><code>{item["file_number"]}</code><br><br><strong>Keywords</strong><br>{" · ".join(item.get("keywords", []))}</div>', unsafe_allow_html=True)
        with y:
            st.markdown(f'<div class="glass"><div class="section-title">Workflow state</div><div style="font-size:2.8rem; font-family:Space Grotesk; color:#2368f2; font-weight:700;">{item["confidence"]}%</div><div class="mini">classification confidence</div><br>{status_pill(item["status"])}<br><br><div class="mini">{item.get("related_documents", 0)} related documents found<br>Received on {item["date_received"]}</div></div>', unsafe_allow_html=True)
    else:
        st.info("No documents match the current search.")

elif page == "File index":
    st.markdown('<div class="eyebrow">Office filing structure</div><div class="section-title" style="font-size:2rem; margin:.25rem 0 .4rem;">File index</div><div class="mini">The recommendation engine learns from this approved index rather than inventing categories.</div>', unsafe_allow_html=True)
    q = st.text_input("Search file index", placeholder="Try ICT, KDEAP, Finance, HR, or a file number")
    visible = file_index if not q else [f for f in file_index if q.lower() in str(f).lower()]
    st.dataframe(pd.DataFrame(visible), use_container_width=True, hide_index=True, height=340)
    with st.expander("Add a new file to the demo index"):
        with st.form("new_file"):
            a, b = st.columns(2)
            title = a.text_input("File title")
            number = b.text_input("File number")
            classification = a.text_input("Classification")
            department = b.text_input("Department")
            location = a.text_input("Physical / digital location", value="To be assigned")
            submit = st.form_submit_button("Add file")
            if submit:
                if title and number:
                    file_index.append({"file_number": number, "title": title, "classification": classification or "General Records", "department": department or "General Records", "opening_date": datetime.now().strftime("%Y-%m-%d"), "status": "Active", "location": location}); add_audit("New file index entry created", title, tone="success"); st.success("File added to the current session."); st.rerun()
                else:
                    st.warning("File title and file number are required.")

elif page == "AI assistant":
    st.markdown('<div class="eyebrow">Ask the registry</div><div class="section-title" style="font-size:2rem; margin:.25rem 0 .4rem;">AI filing assistant</div><div class="mini">Search the demo index in plain language. Add Ollama locally when you are ready for richer answers.</div>', unsafe_allow_html=True)
    prompt = st.text_area("Question", placeholder="Where should I file a letter about KDEAP?\nShow previous correspondence concerning Germany.", height=110)
    c1, c2 = st.columns([1, 1])
    with c1:
        use_ollama = st.toggle("Use local Ollama when available", value=False)
    with c2:
        run = st.button("Search records", type="primary", use_container_width=True)
    if run and prompt.strip():
        response, matches = search_records(prompt, documents, file_index)
        if use_ollama:
            context = "\n".join(f"{r.get('file_number', '')} | {r.get('title', '')} | {r.get('classification', '')}" for r in matches)
            response = ollama_answer(prompt, context) or response
        st.markdown(f'<div class="glass"><div class="eyebrow">Assistant response</div><div style="font-size:1.08rem; color:#234466; line-height:1.65;">{response}</div></div>', unsafe_allow_html=True)
        if matches:
            st.markdown("### Related records")
            for match in matches:
                st.markdown(f"- **{match.get('file_number', 'Record')}** — {match.get('title', 'Untitled')} · {match.get('department', 'General Records')}")
    elif not prompt.strip():
        st.info("Try: “Find all letters about KDEAP received in 2026.”")

elif page == "Audit trail":
    st.markdown('<div class="eyebrow">Accountability by design</div><div class="section-title" style="font-size:2rem; margin:.25rem 0 .4rem;">Audit trail</div><div class="mini">A transparent history of uploads, AI recommendations, and officer decisions.</div>', unsafe_allow_html=True)
    audit_df = pd.DataFrame(st.session_state.audit_trail)
    st.dataframe(audit_df.rename(columns={"time":"Time", "event":"Event", "subject":"Subject", "actor":"Actor", "tone":"Type"}), use_container_width=True, hide_index=True, height=420)
    st.download_button("Download audit trail CSV", audit_df.to_csv(index=False).encode("utf-8"), "airra_audit_trail.csv", "text/csv")

st.markdown("<br><div style='text-align:center; color:#7890aa; font-size:.75rem;'>AIRRA demo · Human approval remains required before official filing · Replace synthetic data with your approved office index</div>", unsafe_allow_html=True)

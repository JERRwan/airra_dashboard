from __future__ import annotations

import io
import json
import os
import re
from pathlib import Path
from typing import Any

import requests

DATA_PATH = Path(__file__).parent / "data" / "demo_data.json"


def load_demo_data() -> dict[str, Any]:
    with DATA_PATH.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def extract_text(file_name: str, raw_bytes: bytes) -> str:
    """Extract text from common office formats without requiring cloud services."""
    suffix = Path(file_name).suffix.lower()
    if suffix == ".pdf":
        try:
            from pypdf import PdfReader

            reader = PdfReader(io.BytesIO(raw_bytes))
            return "\n".join(page.extract_text() or "" for page in reader.pages).strip()
        except Exception:
            return ""
    if suffix == ".docx":
        try:
            from docx import Document

            document = Document(io.BytesIO(raw_bytes))
            return "\n".join(paragraph.text for paragraph in document.paragraphs).strip()
        except Exception:
            return ""
    if suffix in {".txt", ".md", ".csv", ".json"}:
        return raw_bytes.decode("utf-8", errors="ignore").strip()
    if suffix in {".png", ".jpg", ".jpeg", ".tif", ".tiff", ".bmp"}:
        try:
            from PIL import Image
            import pytesseract

            return pytesseract.image_to_string(Image.open(io.BytesIO(raw_bytes))).strip()
        except Exception:
            return ""
    return ""


def _normalise(value: str) -> str:
    return re.sub(r"[^a-z0-9]+", " ", value.lower()).strip()


def classify_document(text: str, file_name: str, file_index: list[dict[str, Any]]) -> dict[str, Any]:
    """Return a transparent, deterministic baseline recommendation for the MVP."""
    haystack = _normalise(f"{file_name} {text}")
    rules = [
        ("kdeap", "ICT / Digital Economy / KDEAP", "ICT / Digital Economy", "ICT/DE/KDEAP/2026", 96, ["digital economy", "KDEAP", "support", "ICT"]),
        ("germany", "External Relations / Germany", "Administration", "EXT/GER/2026", 91, ["Germany", "cooperation", "development"]),
        ("lift", "Administration / Facilities / Lifts", "Facilities", "ADM/FAC/LIFT/2026", 88, ["lift", "maintenance", "facilities"]),
        ("welfare", "Human Resource / Staff Welfare / Training", "Human Resource", "HR/SW/TRN/2026", 93, ["staff welfare", "training", "human resource"]),
        ("training", "Human Resource / Staff Welfare / Training", "Human Resource", "HR/SW/TRN/2026", 90, ["training", "staff welfare"]),
        ("expenditure", "Finance / Expenditure / Circulars", "Finance", "FIN/EXP/CIR/2026", 97, ["budget", "expenditure", "finance"]),
        ("budget", "Finance / Expenditure / Circulars", "Finance", "FIN/EXP/CIR/2026", 95, ["budget", "expenditure", "finance"]),
        ("infrastructure", "ICT / Infrastructure / Projects", "ICT / Infrastructure", "ICT/INF/PRJ/2026", 90, ["infrastructure", "upgrade", "project"]),
    ]
    for trigger, classification, department, file_number, confidence, keywords in rules:
        if trigger in haystack:
            return {
                "document_type": "Official correspondence" if "letter" in haystack or "request" in haystack else "Uploaded office document",
                "subject": (text.splitlines()[0].strip() if text.splitlines() and text.splitlines()[0].strip() else Path(file_name).stem.replace("_", " ").title())[:120],
                "department": department,
                "classification": classification,
                "file_number": file_number,
                "keywords": keywords,
                "confidence": confidence,
                "related_documents": next((item.get("related_documents", 0) for item in file_index if item.get("file_number") == file_number), 0),
                "status": "Awaiting approval",
            }
    fallback = file_index[0] if file_index else {}
    return {
        "document_type": "Uploaded office document",
        "subject": (text.splitlines()[0].strip() if text.splitlines() and text.splitlines()[0].strip() else Path(file_name).stem.replace("_", " ").title())[:120],
        "department": fallback.get("department", "General Records"),
        "classification": fallback.get("classification", "General Records / To Review"),
        "file_number": fallback.get("file_number", "NEW/REVIEW/2026"),
        "keywords": ["uploaded", "review required"],
        "confidence": 62,
        "related_documents": 0,
        "status": "Awaiting approval",
    }


def search_records(question: str, documents: list[dict[str, Any]], file_index: list[dict[str, Any]]) -> tuple[str, list[dict[str, Any]]]:
    terms = [term for term in re.findall(r"[a-z0-9]+", question.lower()) if len(term) > 2]
    scored: list[tuple[int, dict[str, Any]]] = []
    for record in documents:
        haystack = _normalise(" ".join(str(record.get(key, "")) for key in ["title", "department", "classification", "file_number", "sender", "keywords"]))
        score = sum(1 for term in terms if term in haystack)
        if score:
            scored.append((score, record))
    for record in file_index:
        haystack = _normalise(" ".join(str(record.get(key, "")) for key in ["title", "department", "classification", "file_number"]))
        score = sum(1 for term in terms if term in haystack)
        if score:
            scored.append((score, record))
    results = [record for _, record in sorted(scored, key=lambda pair: pair[0], reverse=True)[:8]]
    if results:
        lead = results[0]
        file_number = lead.get("file_number", "the matching file")
        response = f"I found {len(results)} related record(s). The strongest match is **{file_number}** — {lead.get('title', 'matching record')}."
    else:
        response = "I could not find a confident match in the current demo index. Try a file number, department, subject, or keyword such as KDEAP, Germany, lift, training, or expenditure."
    return response, results


def ollama_answer(question: str, context: str) -> str | None:
    """Use Ollama when configured; otherwise let the dashboard stay fully offline."""
    base_url = os.getenv("OLLAMA_BASE_URL", "http://localhost:11434").rstrip("/")
    model = os.getenv("OLLAMA_MODEL", "llama3.2:3b")
    try:
        response = requests.post(
            f"{base_url}/api/generate",
            json={
                "model": model,
                "prompt": f"You are a careful records registry assistant. Use only this context:\n{context}\n\nQuestion: {question}",
                "stream": False,
            },
            timeout=8,
        )
        response.raise_for_status()
        return response.json().get("response", "").strip() or None
    except Exception:
        return None


# End of service layer.

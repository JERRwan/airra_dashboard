# AIRRA — AI Records & Registry Assistant

AIRRA is a Python Streamlit dashboard for receiving documents, extracting text, suggesting a filing classification, matching the approved file index, and keeping an auditable human-approval workflow. The project is based on the supplied AI Records & Filing Assistant brief and uses synthetic demo records so it can be opened immediately in Visual Studio Code.

## Included in this MVP

- Glassmorphism dashboard with overview KPIs and workload chart.
- Document upload for PDF, Word, image, and text files.
- Local extraction using `pypdf`, `python-docx`, and optional Tesseract OCR.
- Deterministic offline classification and file matching rules for the demo.
- Human approval queue with approve and change-file actions.
- Searchable documents and file index views.
- Plain-language AI filing assistant with optional local Ollama support.
- Downloadable audit trail CSV.

> This is a working demonstration. Replace `data/demo_data.json` with the office's approved file index and add authentication, persistent storage, and formal records-management controls before production use.

## Run in Visual Studio Code

Open the `airra_dashboard` folder in Visual Studio Code, create a virtual environment, and install the dependencies:

```bash
python -m venv .venv
```

Windows PowerShell:

```powershell
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
streamlit run app.py
```

macOS / Linux:

```bash
source .venv/bin/activate
pip install -r requirements.txt
streamlit run app.py
```

The dashboard normally opens at `http://localhost:8501`.

## Optional OCR setup

The Python package `pytesseract` is included, but scanned-image OCR also needs the Tesseract executable installed on the machine. On Windows, install Tesseract and add its install directory to PATH. On Ubuntu, run `sudo apt install tesseract-ocr`. If Tesseract is not available, PDF, Word, and text uploads still work.

## Optional offline AI setup with Ollama

Install Ollama separately, pull a local model, and set these variables in `.env` or the terminal:

```text
OLLAMA_BASE_URL=http://localhost:11434
OLLAMA_MODEL=llama3.2:3b
```

Then switch on **Use local Ollama when available** inside the AI assistant page. The dashboard falls back to its transparent local search logic if Ollama is unavailable.

## Project structure

```text
airra_dashboard/
├── app.py                 # Streamlit interface and workflow actions
├── services.py            # Extraction, classification, search, and Ollama helpers
├── requirements.txt       # Installable Python dependencies
├── data/
│   └── demo_data.json     # Synthetic documents, file index, and audit events
├── .env.example           # Optional local AI configuration template
├── .gitignore
└── README.md
```

## Important implementation note

AIRRA intentionally keeps a human in the loop. The AI recommendation is not treated as an official filing decision until a records officer approves it. For a production version, the next recommended steps are a MySQL or PostgreSQL data layer, role-based authentication, encrypted file storage, immutable audit logging, office-index import, and formal retention and access policies.
